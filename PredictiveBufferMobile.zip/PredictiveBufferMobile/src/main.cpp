// Predictive Input Buffer - mobile-friendly rewrite.
// NOTE: written from scratch (the original is a closed-source Windows DLL).
// Same idea / same stages, but no keyboard (F6) dependency, so it works on touch devices.
#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>

using namespace geode::prelude;

namespace {
    struct StageInfo { int press; int wave; const char* label; };
    constexpr StageInfo STAGES[5] = {
        {2, 2, "2/2"}, {4, 4, "4/4"}, {8, 8, "8/8"}, {16, 8, "16/8"}, {0, 0, "OFF"}
    };

    int getStage() {
        return std::clamp<int>(Mod::get()->getSettingValue<int64_t>("stage"), 1, 5) - 1;
    }
    bool isEnabled() {
        return Mod::get()->getSettingValue<bool>("enabled") && getStage() != 4;
    }
}

// Per-player buffer state
struct Buf {
    int pressTicks = 0;      // remaining ticks a pending press stays alive
    int button = 1;
    int releaseTicks = 0;    // remaining ticks before a delayed wave release fires
    bool replaying = false;  // guard so our own handleButton calls aren't re-buffered
};

class $modify(BufBaseGameLayer, GJBaseGameLayer) {
    struct Fields {
        Buf p[2];
    };

    void resetBuf() {
        m_fields->p[0] = Buf{};
        m_fields->p[1] = Buf{};
    }

    bool touchingRing(PlayerObject* pl) {
        return pl && !pl->m_touchedRings.empty();
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        auto& b = m_fields->p[isPlayer1 ? 0 : 1];
        if (b.replaying || !isEnabled() || !PlayLayer::get()) {
            return GJBaseGameLayer::handleButton(down, button, isPlayer1);
        }
        auto* pl = isPlayer1 ? m_player1 : m_player2;
        auto st = STAGES[getStage()];

        if (down) {
            b.releaseTicks = 0;               // new press cancels pending release
            b.button = button;
            b.pressTicks = st.press;          // keep press alive for N ticks
        } else {
            b.pressTicks = 0;                 // released: stop buffering press
            if (pl && pl->m_isDart && st.wave > 0 && button == 1) {
                // wave: hold the release for up to N ticks (forgiveness window)
                b.releaseTicks = st.wave;
                return;                        // swallow now, replay in processCommands
            }
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt) {
        GJBaseGameLayer::processCommands(dt);
        if (!isEnabled()) return;
        for (int i = 0; i < 2; ++i) {
            auto& b = m_fields->p[i];
            bool p1 = i == 0;
            auto* pl = p1 ? m_player1 : m_player2;
            if (!pl) continue;

            // buffered press: fire again once a ring/orb is actually being touched
            if (b.pressTicks > 0) {
                --b.pressTicks;
                if (touchingRing(pl)) {
                    b.replaying = true;
                    GJBaseGameLayer::handleButton(true, b.button, p1);
                    b.replaying = false;
                    b.pressTicks = 0;
                }
            }
            // delayed wave release
            if (b.releaseTicks > 0 && --b.releaseTicks == 0) {
                b.replaying = true;
                GJBaseGameLayer::handleButton(false, b.button, p1);
                b.replaying = false;
            }
        }
    }
};

class $modify(BufPlayLayer, PlayLayer) {
    void resetLevel() {
        PlayLayer::resetLevel();
        static_cast<BufBaseGameLayer*>(static_cast<GJBaseGameLayer*>(this))->resetBuf();
    }
};

// Touch replacement for the F6 key: a button in the pause menu.
class $modify(BufPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        auto label = CCLabelBMFont::create(fmt::format("Buffer: {}", STAGES[getStage()].label).c_str(), "bigFont.fnt");
        label->setScale(0.45f);
        auto item = CCMenuItemExt::createSpriteExtra(label, [label](CCObject*) {
            int next = (getStage() + 1) % 5;
            Mod::get()->setSettingValue<int64_t>("stage", next + 1);
            label->setString(fmt::format("Buffer: {}", STAGES[next].label).c_str());
        });
        auto menu = CCMenu::create();
        menu->addChild(item);
        auto win = CCDirector::get()->getWinSize();
        menu->setPosition({win.width - 60.f, 20.f});
        menu->setID("predictive-buffer-menu"_spr);
        this->addChild(menu);
    }
};
