# Predictive Input Buffer (Mobile)

Input buffer for rings/orbs plus a short wave-release buffer.

**Stages** (ticks = physics steps, 240 per second at 60 fps = 4 ticks/frame in 2.2):

| Stage | Press buffer | Wave release |
|---|---|---|
| 1 | 2 | 2 |
| 2 | 4 | 4 |
| 3 | 8 | 8 |
| 4 | 16 | 8 |
| 5 | OFF | OFF |

On phone there is no F6 key: change the stage from the **pause menu button** or from the mod settings.
