# Predictive Input Buffer – Mobile

1. Crea un repo en GitHub y sube todo este contenido.
2. Pestaña **Actions → Build Android + Windows → Run workflow**.
3. Descarga el artefacto "Build Output": el `.geode` incluye Windows + Android32 + Android64.
4. Copia el `.geode` a `Android/data/com.geode.launcher/files/geode/mods/` (o instálalo desde Geode launcher) con GD 2.2081.

Cambiar de stage en celular: botón "Buffer: X" en el menú de pausa, o en ajustes del mod.
